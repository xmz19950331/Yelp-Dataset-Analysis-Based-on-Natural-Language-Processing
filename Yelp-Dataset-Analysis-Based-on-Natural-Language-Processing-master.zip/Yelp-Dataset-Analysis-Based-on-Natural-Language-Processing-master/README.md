# Yelp-Dataset-Analysis-Based-on-Natural-Language-Processing
Team Members: Jingping Nie (jn2551) Mingzhi Xu (mx2178)Chuhan Li (cl3619)
We encounterd a "unborn repository bug" on Github Desktop. Sorry for 30min late.
This folders contain our source code including models, server and html
If you have any question, please feel free to send email to mx2178@columbia.edu
